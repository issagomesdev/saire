@include('site.layouts.header')

<div style="margin: 2em 0em 5em 0em; word-wrap: break-word;">

{!! $page->content !!} 

</div>

</div> <!-- content close -->

@include('site.layouts.footer')