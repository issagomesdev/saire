<?php

return [
    'site_title' => 'Prefeitura Municipal de Sairé',

];
