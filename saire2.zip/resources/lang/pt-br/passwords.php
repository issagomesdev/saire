<?php

return [
    'password' => 'As senhas devem ter pelo menos seis caracteres e combinar a confirmação.',
    'reset'    => 'a senha foi alterada!',
    'sent'     => 'Enviamos seu link de redefinição de senha por e-mail!',
    'token'    => 'Token de redefinição de senha é inválido.',
    'user'     => 'Não encontramos um usuário com esse endereço de e-mail.',
    'updated'  => 'A palavra-passe foi alterada',

];
