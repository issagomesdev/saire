<footer>

	<div class="footer-content">

		<div class="footer-widget">
			<div class="footer-widget-top">
				<p> sairé – pe trabalhando junto com o povo </p>
				<div class="footer-widget-line"> </div>
			</div>

			<div class="footer-widget-container">
				<p> <i class="fa-solid fa-location-dot"></i> Avenida Cel. José Pessoa, S/N Centro, Sairé/PE CEP: 55.695-000 </p>
				<p> <i class="fa-solid fa-phone-flip"></i> (81) 3748-1156 </p>
				<p> <i class="fa-solid fa-envelope"></i> imprensa@saire.pe.gov.br </p>
				<p> <i class="fa-solid fa-clock"></i> 08:00 as 13:00 </p>
			</div>
		</div>

		<div class="footer-widget">
			<div class="footer-widget-top">
				<p> Guia Rápido </p>
				<div class="footer-widget-line"> </div>
			</div>

			<div class="footer-widget-container">
				<p> <a href="<?php echo e(route('site.publications')); ?>"> Notícias </a> </p>
				<p> <a href="pagina/Município"> Município </a> </p>
				<p> <a href="pagina/Governo-Municipal"> Governo Municipal </a> </p>
				<p> <a href="pagina/Secretarias"> Secretarias </a> </p>
				<p> <a href="https://transparencia.saire.pe.gov.br/portal/v81/p_index/p_index.php"> Portal da Transparencia </a> </p>
				<p> <a href="https://transparencia.saire.pe.gov.br/portal/v81/p_acesso_rapido/p_acesso_rapido.php"> Ouvidoria </a> </p>
			</div>
		</div>

		<div class="footer-widget">
			<div class="footer-widget-top">
				<p> Redes Sociais </p>
				<div class="footer-widget-line"> </div>
			</div>

			<div class="footer-widget-container">
				<div class="social">
				<a href="https://www.instagram.com/governodesaire/" class="fa-brands fa-square-instagram"></a>
				<a href="https://www.facebook.com/governosaire/?locale=pt_BR" class="fa-brands fa-facebook"></a>
				</div>
			</div>
		</div>

	</div>

	<div class="copyright"> 
		<p> © Copyright - 2023 Prefeitura Municipal de Sairé - PE | Desenvolvido por  
		<a href="https://www.linkedin.com/in/byissa/"> Hayssa Gomes </a> </p>
	</div>

	</footer><?php /**PATH C:\wamp64\www\saire\resources\views/site/layouts/footer.blade.php ENDPATH**/ ?>