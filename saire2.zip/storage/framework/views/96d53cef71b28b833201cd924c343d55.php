<?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="<?php echo e(asset('css/site/page.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('css/site/galleries/styles.css')); ?>" rel="stylesheet" />

<div class="gallery-content">
<div class="display-imagen" visible="false">

  <div class="details">
   <div class="open-details"> <i class="fa-solid fa-ellipsis-vertical"> </i> </div>
  </div>

  <div class="details-item" visible="false">

  <div class="items-data">
    <div id="title" class="item-data">
    <i class="fa-solid fa-file-signature"></i>
    <p> </p>
    </div>

    <div id="description" class="item-data">
    <i class="fa-solid fa-align-center"></i>
    <p> </p>
    </div>

    <div id="date" class="item-data">
    <i class="fa-solid fa-calendar-days"></i>
    <p> </p>
    </div>

    <div id="categories" class="item-data">
    <i class="fa-solid fa-tags"></i>
    <div class="categories-items">

    </div>
    </div>
  </div>

  </div>


  <div class="close"> <i class="fa-solid fa-xmark"></i> </div>
  <div class="change-image" id="previous"> <i class="fa-solid fa-circle-chevron-left"></i> </div>
  <img>
  <div class="change-image" id="next"> <i class="fa-solid fa-circle-chevron-right"></i> </div>
</div>

<div class="galleries"> </div>
<div class="pagination"> </div>

</div>
</div> <!-- content close -->

<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>

const url = "<?php echo e(Request::url()); ?>"
const next = <?php echo e($galleries->currentPage()); ?> == <?php echo e($galleries->lastPage()); ?>? 0 :
(<?php echo e($galleries->lastPage()); ?> - <?php echo e($galleries->currentPage()); ?>) >= 3? 3 : 
(<?php echo e($galleries->lastPage()); ?> - <?php echo e($galleries->currentPage()); ?>);


const previus = <?php echo e($galleries->currentPage()); ?> == 1? 0 :
(<?php echo e($galleries->currentPage()); ?> - 1) >= 3? 3 : 
(<?php echo e($galleries->currentPage()); ?> - 1);

const currentPage = "<?php echo e($galleries->currentPage()); ?>"
const lastPage = "<?php echo e($galleries->lastPage()); ?>"
const nextPages = []
const previusPages = []

for(let i = (<?php echo e($galleries->currentPage()); ?> + 1); i <= (<?php echo e($galleries->currentPage()); ?> + next); i++) {
    nextPages.push([i]);
  }

  for(let i = (<?php echo e($galleries->currentPage()); ?> - 1); i >= (<?php echo e($galleries->currentPage()); ?> - previus); i--) {
    previusPages.push([i]);
  }

</script>
<script src="<?php echo e(asset('js/site/page.js')); ?>"> </script>
<script>

const galleries = [
			<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		{
			"id": "<?php echo e($gallery->id); ?>",  
			"title": "<?php echo e($gallery->title); ?>",
			"description": "<?php echo e($gallery->description); ?>",
      "date": "<?php echo e($gallery->created_at); ?>",
      "categories": [
            <?php $__currentLoopData = $gallery->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($category->title); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
			"photos": [
			<?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($media->getUrl()); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			],
			
		},

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		];

</script>
<script src="<?php echo e(asset('js/site/galleries/script.js')); ?>"> </script>
</body>
</html><?php /**PATH C:\wamp64\www\saire\resources\views/site/galleries/index.blade.php ENDPATH**/ ?>