<?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="<?php echo e(asset('css/site/publications/show.css')); ?>" rel="stylesheet" />

<div class="page-content">

    <div class="publication-content">

        <div class="publication-imagen">
        <a> </a>
        <div class="publication-imagens"> </div>
        </div>

        <div class="publication-title">
            <p><?php echo e($publication->title); ?></p>
        </div>

        <div class="publication-text">
            <p><?php echo $publication->text; ?></p>
        </div>

        <div class="publication-categories">
        <?php $__currentLoopData = $publication->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($categories->title); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="publication-date">
        <p>Publicado em <?php echo e($publication->created_at); ?></p>
        </div>

    </div>

    <div class="navigation-pages">
        
        <?php if($previus): ?>
        <div class="navigate">
        <a href="<?php echo e(route('site.publications.show', str_replace(" ", "_", $previus->title))); ?>" class="fa-solid fa-angles-left"></a>
        <div class="navigate-page">
        <div class="navigate-page-lab"> Anterior: </div>
        <a> <?php echo e($previus->title); ?> </a> 
        </div>
        </div>
        <?php endif; ?>
        
        <?php if($next): ?>
        <div class="navigate">
        <div class="navigate-page"> 
        <div class="navigate-page-lab"> Próximo: </div>
        <a> <?php echo e($next->title); ?> </a> 
        </div>
        <a href="<?php echo e(route('site.publications.show', str_replace(" ", "_", $next->title))); ?>" class="fa-solid fa-angles-right"></a>
        </div>
        <?php endif; ?>

    </div>
    

</div>

</div> <!-- content close -->

<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>

const publication_imagens = [
			<?php $__currentLoopData = $publication->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($media->getUrl()); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			]
</script>

<script src="<?php echo e(asset('js/site/publications/show.js')); ?>"> </script>

</body>
</html><?php /**PATH C:\wamp64\www\saire\resources\views/site/publications/show.blade.php ENDPATH**/ ?>