<?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<link href="<?php echo e(asset('css/site/styles.css')); ?>" rel="stylesheet" />

<main>
	<div class="fav-gallery-content">
	<section id="fav">
			<div class="features"> </div>
		</section>
		
		<section id="gallery">
			<div class="lab">
				<a href="<?php echo e(route('site.gallery')); ?>"> galeria de fotos <i class="fa-solid fa-link"></i> </a> 
			</div>
			<div class="images"> </div>
			<div class="view-more" id="gallery">
				<a href="<?php echo e(route('site.gallery')); ?>"> ver mais da galeria <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
			</div>
		</section>
	</div>

	<section class="banners">
		<div class="banner"> <a href="https://saire.pe.gov.br/pagina/Precat%C3%B3rio_FUNDEF_2023"> <img src="<?php echo e(asset('storage/img/banners/fundef.jpeg')); ?>" alt=" Precatório FUNDEF 2023"> </a> </div>
		<div class="banner"> <a href="https://saire.pe.gov.br/pagina/Eleição_Conselho_Tutelar"> <img src="<?php echo e(asset('storage/img/banners/conselho.png')); ?>" alt="Processo de Escolha 2023 - Conselho Tutelar"> </a> </div>
		<div class="banner"> <a href="http://www.ebminformatica.com/tributos/index.php"> <img src="<?php echo e(asset('storage/img/banners/iptu.png')); ?>" alt="iptu"> </a> </div>
		<div class="banner"> <a href="https://transparencia.saire.pe.gov.br/portal/v81/indexent/indexent.php?entidade=215&idoc=holerite2"> <img src="<?php echo e(asset('storage/img/banners/contracheque.png')); ?>" alt="contracheque"> </a> </div>
		<div class="banner"> <a href="http://transparencia.saire.pe.gov.br/portal/v81/indexent/indexent.php?entidade=215&idoc=lic"> <img src="<?php echo e(asset('storage/img/banners/licitacao.png')); ?>" alt="licitação"> </a> </div>
		<div class="banner"> <a href="http://transparencia.saire.pe.gov.br/portal/v81/indexent/indexent.php?entidade=215&idoc=lic">  <img src="<?php echo e(asset('storage/img/banners/aviso-de-licitacao.png')); ?>" alt="aviso de licitação"> </a> </div>
		<div class="banner"> <a href="http://www.ebminformatica.com/enota25/site/login/login"> <img src="<?php echo e(asset('storage/img/banners/nfse.png')); ?>" alt="nfse"> </a> </div>
		<div class="banner"> <a href="http://transparencia.saire.pe.gov.br/portal/v81/indexent/indexent.php?entidade=215&idoc=serv"> <img src="<?php echo e(asset('storage/img/banners/carta.png')); ?>" alt="carta de serviços"> </a> </div>
		<div class="banner"> <a href="http://transparencia.saire.pe.gov.br/portal/v81/indexent/indexent.php?entidade=215&idoc=dpa"> <img src="<?php echo e(asset('storage/img/banners/despesas.png')); ?>" alt="despesa"> </a> </div>
		<div class="banner"> <a href="http://transparencia.saire.pe.gov.br/portal/v81/indexent/indexent.php?entidade=215&idoc=rec"> <img src="<?php echo e(asset('storage/img/banners/receita.png')); ?>" alt="receita"> </a> </div>
		<div class="banner"> <a href="https://transparencia.saire.pe.gov.br/portal/v81/covid_home/"> <img src="<?php echo e(asset('storage/img/banners/covid.png')); ?>" alt="covid-19"> </a> </div>
	</section>
</main>

	<section id="publications">
		<div class="lab">
			<a href="<?php echo e(route('site.publications')); ?>"> últimas notícias <i class="fa-solid fa-link"> </i> </a> 
		</div>
		<div class="publications"> </div>
		<div class="view-more"  id="publications">
			<a href="<?php echo e(route('site.publications')); ?>"> ver todas as notícias <i class="fa-solid fa-arrow-up-right-from-square"></i> </a>
		</div>
	</section>
		</div> <!-- content close -->

		<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<script>

		const publications = [
			<?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		{
			"id": "<?php echo e($publication->id); ?>",  
			"title": "<?php echo e($publication->title); ?>",
			"text": "<?php echo e($publication->text); ?>",
			"status": "<?php echo e($publication->status); ?>",         
			"photos": [
			<?php $__currentLoopData = $publication->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($media->getUrl()); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			],
			
		},

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		];

		const featuredPublications = [
			<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		{ 
			"id": "<?php echo e($feature->id); ?>", 
			"title": "<?php echo e($feature->title); ?>",
			"text": "<?php echo e($feature->text); ?>",
			"status": "<?php echo e($feature->status); ?>",          
			"photos": [
			<?php $__currentLoopData = $feature->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($media->getUrl()); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			],
			
		},
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		];

		var imageDefault = "<?php echo e(asset('storage/img/saire.jpeg')); ?>";

		const galleries = [
			<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		{ 
			"id": "<?php echo e($gallery->id); ?>", 
			"title": "<?php echo e($gallery->title); ?>",          
			"photos": [
			<?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($media->getUrl()); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			],
			
		},
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		];
		
	</script>
<script src="<?php echo e(asset('js/he-master/he.js')); ?>"> </script>
<script src="<?php echo e(asset('js/site/script.js')); ?>"> </script>

	<style>
	
	span.text-big {
	background-color: rgb(255 255 255 / 0%) !important;
    color: #fff !important;
    }
	
	</style>


</body>
</html><?php /**PATH C:\wamp64\www\saire\resources\views/site/index.blade.php ENDPATH**/ ?>