<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
    <img src="<?php echo e(asset('storage/img/logo1.png')); ?>" alt="logo" style="width: 18em; height: auto">
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.permissions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-unlock-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.roles.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-file-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.auditLog.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('site_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/publications*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/galleries*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-desktop c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.site.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('navigation_access')): ?>
                        <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/menus*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/submenus*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/pages*") ? "c-show" : ""); ?>">
                            <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                <i class="fa-fw fas fa-mouse-pointer c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.navigation.title')); ?>

                            </a>
                            <ul class="c-sidebar-nav-dropdown-items">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu_access')): ?>
                                    <li class="c-sidebar-nav-item">
                                        <a href="<?php echo e(route("admin.menus.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/menus") || request()->is("admin/menus/*") ? "c-active" : ""); ?>">
                                            <i class="fa-fw fas fa-ellipsis-h c-sidebar-nav-icon">

                                            </i>
                                            <?php echo e(trans('cruds.menu.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('submenu_access')): ?>
                                    <li class="c-sidebar-nav-item">
                                        <a href="<?php echo e(route("admin.submenus.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/submenus") || request()->is("admin/submenus/*") ? "c-active" : ""); ?>">
                                            <i class="fa-fw fas fa-ellipsis-v c-sidebar-nav-icon">

                                            </i>
                                            <?php echo e(trans('cruds.submenu.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('page_access')): ?>
                                    <li class="c-sidebar-nav-item">
                                        <a href="<?php echo e(route("admin.pages.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/pages") || request()->is("admin/pages/*") ? "c-active" : ""); ?>">
                                            <i class="fa-fw fas fa-align-center c-sidebar-nav-icon">

                                            </i>
                                            <?php echo e(trans('cruds.page.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/categories") || request()->is("admin/categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-tags c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.category.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('publication_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.publications.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/publications") || request()->is("admin/publications/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-align-center c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.publication.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.galleries.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/galleries") || request()->is("admin/galleries/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-images c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.gallery.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                <li class="c-sidebar-nav-item">
                    <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                        <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                        </i>
                        <?php echo e(trans('global.change_password')); ?>

                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        <li class="c-sidebar-nav-item">
            <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                </i>
                <?php echo e(trans('global.logout')); ?>

            </a>
        </li>
    </ul>

</div><?php /**PATH C:\wamp64\www\saire\resources\views/partials/menu.blade.php ENDPATH**/ ?>