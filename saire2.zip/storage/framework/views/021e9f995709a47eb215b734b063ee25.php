<?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="<?php echo e(asset('css/site/page.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('css/site/publications/styles.css')); ?>" rel="stylesheet" />

<div class="page-content">
    <div class="publications-content"> </div>
</div> 
<div class="pagination"> </div>

</div> <!-- content close -->

<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


<script src="<?php echo e(asset('js/he-master/he.js')); ?>"> </script>
<script>

const url = "<?php echo e(Request::url()); ?>"
const next = <?php echo e($publications->currentPage()); ?> == <?php echo e($publications->lastPage()); ?>? 0 :
(<?php echo e($publications->lastPage()); ?> - <?php echo e($publications->currentPage()); ?>) >= 3? 3 : 
(<?php echo e($publications->lastPage()); ?> - <?php echo e($publications->currentPage()); ?>);


const previus = <?php echo e($publications->currentPage()); ?> == 1? 0 :
(<?php echo e($publications->currentPage()); ?> - 1) >= 3? 3 : 
(<?php echo e($publications->currentPage()); ?> - 1);

const currentPage = "<?php echo e($publications->currentPage()); ?>"
const lastPage = "<?php echo e($publications->lastPage()); ?>"
const nextPages = []
const previusPages = []

for(let i = (<?php echo e($publications->currentPage()); ?> + 1); i <= (<?php echo e($publications->currentPage()); ?> + next); i++) {
    nextPages.push([i]);
  }

  for(let i = (<?php echo e($publications->currentPage()); ?> - 1); i >= (<?php echo e($publications->currentPage()); ?> - previus); i--) {
    previusPages.push([i]);
  }

</script>
<script src="<?php echo e(asset('js/site/page.js')); ?>"> </script>

<script>

    		const publications = [
			<?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		{
			"id": "<?php echo e($publication->id); ?>",  
			"title": "<?php echo e($publication->title); ?>",
			"text": "<?php echo e($publication->text); ?>",
			"status": "<?php echo e($publication->status); ?>",
            "date": "<?php echo e($publication->created_at); ?>",
            "categories": [
            <?php $__currentLoopData = $publication->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($category->title); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
			"photos": [
			<?php $__currentLoopData = $publication->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			"<?php echo e($media->getUrl()); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			],
			
		},

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		];

		var imageDefault = "<?php echo e(asset('storage/img/saire.jpeg')); ?>";
        
</script>
<script src="<?php echo e(asset('js/site/publications/script.js')); ?>"> </script>

</body>
</html><?php /**PATH C:\wamp64\www\saire\resources\views/site/publications/index.blade.php ENDPATH**/ ?>