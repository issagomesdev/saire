<?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="margin: 2em 0em 5em 0em; word-wrap: break-word;">

<?php echo $page->content; ?> 

</div>

</div> <!-- content close -->

<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\saire\resources\views/site/page.blade.php ENDPATH**/ ?>