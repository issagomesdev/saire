<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Prefeitura Municipal de Sairé</title>
	<link href="<?php echo e(asset('css/site/header.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('css/site/footer.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('css/site/search.css')); ?>" rel="stylesheet" />
	<meta charset="UTF-8" content="width=device-width, initial-scale=1" name="viewport">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</head>
<body>

<div class="top_access">
		<div class="widget-container-social">
			
			<form method="GET" action="<?php echo e(route("site.search")); ?>">
				<div class="search-mob-container">
					<input name="search" id="search" value="<?php echo e(request()->search); ?>" placeholder="Pesquisar..." class="search-mob-input" require>
					<a href="#" class="search-mob-btn">
							<i class="fas fa-search"></i>      
					</a>
				</div>		
			</form>
			<a href="https://www.instagram.com/governodesaire/" class="fa-brands fa-square-instagram"></a>
			<a href="https://www.facebook.com/governosaire/?locale=pt_BR" class="fa-brands fa-facebook"></a>
		</div>
</div>
	
	<div class="content">
	<header style="display: flex;
		justify-content: space-between;
		flex-direction: row;
		width: 100%;">
		<a href="/"> <img src="<?php echo e(asset('storage/img/logo1.png')); ?>" alt="logo"> </a>

		<div class="Search">
			<div class="SearchInner">
				<form method="GET" action="<?php echo e(route("site.search")); ?>">
					<div class="container">
						<button class="Icon" type="submit">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#dddddd" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
						</button>
						<div class="InputContainer">
							<input name="search" id="search"  value="<?php echo e(request()->search); ?>" placeholder="Pesquisar..." require>
						</div>
					</div>
				</form>
			</div>
		</div>
	</header>
	
	<header>
			
		<div class="drop-menu"> 
		<p> menu <i class="fa-solid fa-caret-up"></i>	</p>
		</div>

		<div class="nav" active="true">
			
		<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($menu->link_type == 0): ?>
		<div class="parent-menu"> 
		<a> <?php echo e($menu->title); ?> </a>
		<i class="fa-solid fa-caret-down"></i>
		<div class="child-menu" active="false">
		<?php $__currentLoopData = $menu->submenuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($menuchild->link_type == 0): ?>
		<a href="<?php echo e(route('site.page', str_replace(" ", "_", $menuchild->page->title))); ?>" class="<?php echo e(collect([$menuchild])->contains(function($menuchild) { return str_replace(" ", "_", $menuchild->page->title) == last(explode('/', request()->path())); }) ? 'active' : ''); ?>"> <?php echo e($menuchild->title); ?> </a> 
		<?php elseif($menuchild->link_type == 1): ?>
		<a href="<?php echo e($menuchild->url); ?>"> <?php echo e($menuchild->title); ?> </a>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		</div>
		<?php elseif($menu->link_type == 1): ?>
		<div class="<?php echo e(urldecode(request()->getRequestUri()) == ("/pagina/" . str_replace(" ", "_", $menu->page->title)) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('site.page', str_replace(" ", "_", $menu->page->title))); ?>"> <?php echo e($menu->title); ?> </a> 
		</div>
		<?php elseif($menu->link_type == 2): ?>
		<div class="<?php echo e(urldecode(request()->getRequestUri()) == $menu->url ? 'active' : ''); ?>"> <a href="<?php echo e($menu->url); ?>"> <?php echo e($menu->title); ?> </a> </div>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
	</header>


	<script src="<?php echo e(asset('js/site/parentMenu.js')); ?>"> </script><?php /**PATH C:\wamp64\www\saire\resources\views/site/layouts/header.blade.php ENDPATH**/ ?>