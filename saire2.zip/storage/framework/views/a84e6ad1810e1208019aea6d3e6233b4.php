<?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('css/site/page.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('css/site/search/styles.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('css/site/galleries/styles.css')); ?>" rel="stylesheet" />
<style>
	.display-imagen[visible="true"] {
    height: 95%;
    width: 95%;
    z-index: 999;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
}

	.display-imagen img {
    border-radius: 0;
}
</style>

<div class="search-content">
	
	<!-- display imagen -->
	<div class="display-imagen" visible="false">
	<div class="details">
		<div class="open-details"> <i class="fa-solid fa-ellipsis-vertical"> </i> </div>
	</div>

	<div class="details-item" visible="false">
		<div class="items-data">
			<div id="title" class="item-data">
				<i class="fa-solid fa-file-signature"></i>
				<p> </p>
			</div>

			<div id="description" class="item-data">
				<i class="fa-solid fa-align-center"></i>
				<p> </p>
			</div>

			<div id="date" class="item-data">
				<i class="fa-solid fa-calendar-days"></i>
				<p> </p>
			</div>

			<div id="categories" class="item-data">
				<i class="fa-solid fa-tags"></i>
				<div class="categories-items"> </div>
			</div>
		</div>
	</div>

	<div class="close"> <i class="fa-solid fa-xmark"></i> </div>
	<div class="change-image" id="previous"> <i class="fa-solid fa-circle-chevron-left"></i> </div>
	<img>
	<div class="change-image" id="next"> <i class="fa-solid fa-circle-chevron-right"></i> </div>
</div>

	<!-- publications -->
	<div class="items-conteiner" id="publications">
	<div class="search-lab"> Notícias  <div class="lab-color"> </div> </div>
		<div class="spinner-conteiner">
			<div id="publications" class="spinner"></div>
		</div>
		<div class="items-content" id="publications"> </div>
		<div class="pagination" id="publications">  </div>
	</div>

	<!-- page -->
	<div class="items-conteiner" id="page">
	<div class="search-lab"> Páginas <div class="lab-color"> </div> </div>
		<div class="spinner-conteiner">
			<div id="page" class="spinner"></div>
		</div>
		<div class="items-content" id="page"> </div>
		<div class="pagination" id="page">  </div>
	</div>
</div>

<!-- galleries -->

<div class="items-conteiner" id="galleries">
	<div class="search-lab"> Galeria <div class="lab-color"> </div> </div>
		<div class="spinner-conteiner">
			<div id="galleries" class="spinner"></div>
		</div>
	<div class="items-content" id="galleries"> </div>
	<div class="pagination" id="galleries">  </div>
</div>

<div class="spinner-conteiner">
	<div id="galleries" class="spinner"></div>
</div>

</div> <!-- content close -->

<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/site/search/script.js')); ?>"> </script>
<script src="<?php echo e(asset('js/he-master/he.js')); ?>"> </script>
<script>
	// showSpinner('publications')
	// showSpinner('page')
	// showSpinner('galleries')
loadPublications(1, "<?php echo e($search); ?>",  "<?php echo e(asset('storage/img/saire.jpeg')); ?>");
loadPages(1, "<?php echo e($search); ?>",  "<?php echo e(asset('storage/img/saire.jpeg')); ?>");
loadGalleries(1, "<?php echo e($search); ?>");
</script>
<?php /**PATH C:\wamp64\www\saire\resources\views/site/search.blade.php ENDPATH**/ ?>